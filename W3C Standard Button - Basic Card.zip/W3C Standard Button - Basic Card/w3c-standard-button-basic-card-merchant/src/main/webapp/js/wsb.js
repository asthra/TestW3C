$(document).ready(function() {
	console.log("Ready");
	
	function checkAllValuesAreGood(response) {
		return true;
	}
	
	async function doPaymentRequest(methodData, details, options) {
		  try {
		    const request = new PaymentRequest(methodData, details, options);
		    // See below for a detailed example of handling these events
		    request.onshippingaddresschange = ev => ev.updateWith(details);
		    request.onshippingoptionchange = ev => ev.updateWith(details);
		    const response = await request.show();
		    await validateResponse(response);
		  } catch (err) {
		    // AbortError, SecurityError
		    console.error(err);
		  }
		}
	
	async function validateResponse(response) {
	  try {
	    if (await checkAllValuesAreGood(response)) {
	    console.log(response);
		$('.content').hide();
		$('.txnStatusTbl').show();
		$('.status').html('Card details recieved from the bank (W3C API):');
		$('.cardNumber').html(response.details.cardNumber);
		$('.cardholderName').html(response.details.cardholderName);
		$('.expiryMonth').html(response.details.expiryMonth);
		$('.expiryYear').html(response.details.expiryYear);
		$('.cardSecurityCode').html(response.details.cardSecurityCode);
	     await response.complete("success");
	    } else {
	      await response.complete("fail");
	    }
	  } catch (err) {
	    await response.complete("fail");
	  }
	}
		
	function createPaymentRequestObject() {
		const methodData = [
			     		       {
			     		          supportedMethods: "basic-card",
			     		          data: {
			     		        	  supportedNetworks: ["mastercard", "visa"],
			     		        	  supportedTypes: ["credit", "debit"],
			     		        	  merchantName: "RETAILMINE ONLINE STORE",
			     		          },
			     		          
			     		        }
			     		   ];	
		const details = {
					  id: "order-1",
					  displayItems: [
					    {
					      label: "Sub-total",
					      amount: { currency: "GBP", value: "55.00" },
					    },
					    {
					      label: "Sales Tax",
					      amount: { currency: "GBP", value: "10.00" },
					      type: "tax"
					    },
					  ],
					  total: {
					    label: "Total due",
					    amount: { currency: "GBP", value: "65.00" },
					  },
				};
		const shippingOptions = [
		                         {
		                           id: "standard",
		                           label: "Ground Shipping (2 days)",
		                           amount: { currency: "USD", value: "5.00" },
		                           selected: true,
		                         },
		                         {
		                           id: "drone",
		                           label: "Drone Express (2 hours)",
		                           amount: { currency: "USD", value: "25.00" }
		                         }
		                       ];
		const options = {
				  requestPayerEmail: false,
				  requestPayerName: false,
				  requestPayerPhone: false,
				  requestShipping: false,
				};
		
		
		Object.assign(details, { shippingOptions } );
		doPaymentRequest(methodData, details, options);	
			
	}
	
	$('.w3cBtn').click(function(ev) {
		console.log("Button Clicked");
		createPaymentRequestObject();
	});
});
