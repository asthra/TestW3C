$(document).ready(function() {
	
	function clear() {
		const elements = [
		                  '.success',
		                  '.failure',
		                  '.errCode',
		                  '.errMsg',
		                  '.errStack'
		                ];
        for (const cls of elements) {
        	$(cls).html("");
        }
	}
	
	function fadeOut(elem) {
		$(elem).fadeOut( 3000, function() {
			$(elem).html("");
			$(elem).show();
		});
	}
	
	function hideContent() {
		$('.content').hide();
	}
	
	function showContent() {
		$('.content').show();
	}
	
	function showInstalling() {
		$('.installing').show();
	}
	
	function hideInstalling() {
		$('.installing').hide();
	}
	
	async function installWebApp(){
		try {
			hideContent();
			showInstalling();
			const registration = await navigator.serviceWorker.register("js/app.js");
			await addInstruments(registration);
			setTimeout( () => {
				hideInstalling();
				showContent();
				$('.success').html("Service Worker Installed");
				fadeOut(".success");
				showHideButtons();}, 2000);
		} catch (e) {
			hideInstalling();
			showContent();
			$('.failure').html("Failed To Install Service Worker. Try installing again.");
			if (!e.stack) {
				$('.errCode').html('Error Code:' + e.code);
				$('.errMsg').html('Error Message:' + e.message);
			}
			else {
				$('.errStack').html(e.stack);
			}
		}
		
	}
	
	async function uninstallWebApp() {
		try {
			hideContent();
			showInstalling();
			const registration = await navigator.serviceWorker.getRegistration("js/app.js");
			await registration.unregister();
			setTimeout( () => {
				hideInstalling();
				showContent();
				$('.success').html("Service Worker Uninstalled");
				fadeOut(".success");
				showHideButtons();}, 2000);
		} catch (e) {
			hideInstalling();
			showContent();
			$('.failure').html("Failed To Uninstall Service Worker. Try uninstalling again.");
			if (!e.stack) {
				$('.errCode').html('Error Code:' + e.code);
				$('.errMsg').html('Error Message:' + e.message);
			}
			else {
				$('.errStack').html(e.stack);
			}
		}
	}
	
	$('#install-web-app').click(function(evt) {
		clear();
		installWebApp();
	});
	
	$('#uninstall-web-app').click(function(evt) {
		clear();
		uninstallWebApp();
	});
	
	 function addInstruments(registration) {
         return Promise.all([
            registration.paymentManager.instruments.set(
              "instrument-key",
              {
            	  name: "My ${bank.id} Account",
            	  enabledMethods: ['basic-card'],
            	  method: 'basic-card',
            	  capabilities: {
            		  supportedNetworks: ['visa', 'mastercard'],
            		  supportedTypes: ['credit', 'debit'],
            	  },
              }),

            ]);
	 }

	 
	async function showHideButtons() {
		 const registration = await navigator.serviceWorker.getRegistration("js/app.js");
		 if (registration) {
			 $('#uninstall-web-app').show();
			 $('#install-web-app').hide();
		 } else {
			 $('#install-web-app').show();
			 $('#uninstall-web-app').hide();
		 }
	 }
	 
	 showHideButtons();
	     
});
