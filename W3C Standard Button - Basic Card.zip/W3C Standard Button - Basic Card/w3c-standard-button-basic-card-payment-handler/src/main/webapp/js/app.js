self.addEventListener('paymentrequest', function(e) {
  e.respondWith(new Promise(function(resolve, reject) {
    self.addEventListener('message', listener = function(e) {
      self.removeEventListener('message', listener);
      if (e.data.hasOwnProperty('name')) {
        reject(e.data);
      } else {
        resolve(e.data);
      }
    });

    e.openWindow("${url}${project.name}/login.html")
    .then(function(windowClient) {
    	var data = {merchantName: e.methodData[0].data.merchantName, total: e.total.value, requestId: e.paymentRequestId}
    	setTimeout(() => windowClient.postMessage(data), 2000);
    })
    .catch(function(err) {
      reject(err);
    });
  }));
});
