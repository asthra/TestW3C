package com.w3c.ph.sample;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

@WebServlet("/login/*")
public class PHServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user = request.getParameter("user");
		String password = request.getParameter("password");
		request.setAttribute("name", user);
		request.setCharacterEncoding("utf8");
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        JSONObject json = new JSONObject();
        if (user != null && !user.isEmpty()) {
        	json.put("cardholderName", user.toUpperCase());
        } else {
        	json.put("cardholderName", "John Smith");
        }
        
        json.put("cardNumber", "5412 7512 3412 3456");
        json.put("expiryMonth", "01");
        json.put("expiryYear", "2020");
        json.put("cardSecurityCode", "***");
        out.print(json.toString());
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		super.doGet(req, resp);
		System.out.println(req.getAttribute("user"));
	}
	
}
